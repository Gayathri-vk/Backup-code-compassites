export interface BOQCriticalPath {
  id?: string;
  text: string;
  name: string;

  subitem: string;
  subsubitem: string;

  duration: String;
}
