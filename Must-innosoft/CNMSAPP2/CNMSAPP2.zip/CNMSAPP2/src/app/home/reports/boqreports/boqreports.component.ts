import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

import { BoqdetailreportComponent } from '../boqdetailreport/boqdetailreport.component';

@Component({
  selector: 'app-boqreports',
  templateUrl: './boqreports.component.html',
  styleUrls: ['./boqreports.component.scss']
})
export class BoqreportsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
