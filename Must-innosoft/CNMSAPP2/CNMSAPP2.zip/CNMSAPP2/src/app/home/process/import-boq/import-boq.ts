export interface ImportBOQList {
    sItem: string;
    Description: string;
    MainItem: string;
    SubItem: string;
    SubSubItem: string;
    BoqRef: string;
    Task: string;
    Qty: string;
    Unit: string;
    Rate: string;
    Amount: string;
}
