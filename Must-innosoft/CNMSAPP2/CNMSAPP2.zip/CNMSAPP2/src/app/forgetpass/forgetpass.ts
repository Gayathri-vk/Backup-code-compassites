export interface Forgetpassword {
  ClientCode: string;
  Email: string;
}

export interface ForgetpassRes {
  status: boolean;
  message: string;
}
