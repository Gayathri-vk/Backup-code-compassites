import React, { Component } from 'react'
import Subscribe from './subscribe';
export default class razorpay extends Component {
   
  

  constructor(props) {
    
    super(props);
    
    // this.fetch_pyt=this.fetch_pyt.bind(this);
    this.openCheckout = this.openCheckout.bind(this);
   
    var v = props.price;

    console.log(this.props.price,'price');
  }

 
  // fetch_pyt(){

  //   var instance = new window.Razorpay({
  //     key_id: 'rzp_test_xSEaiyyVnEJyut',
  //     key_secret: 'YwB1CBP94HzTUqBEoNqzhWrD',
     
  //   });
  
  //   console.log(instance.payments.fetch('pay_DfOishZR2i5m68'));
  
  // }
  
  openCheckout(payment_amount) {
    console.log(payment_amount);
    var options = {
      "key": "rzp_test_xSEaiyyVnEJyut",
      "amount": payment_amount*100, 
      "name": "Must Innosoft",
      "description": "Purchase Description",
      "image": "/your_logo.png",
      "handler": function (response){
        alert(response.razorpay_payment_id);        
        console.log(response);  
        const paymentId = response.razorpay_payment_id;
        const url = 'https://rzp_test_xSEaiyyVnEJyut:YwB1CBP94HzTUqBEoNqzhWrD@api.razorpay.com/v1/payments/'+paymentId;
        // Using my server endpoints to capture the payment
        console.log(url,'url');
        fetch(url, {
          method: 'get',
          headers: {
            "Content-type": "application/json"
          }
        })
        .then(resp =>  resp.json())
        .then(function (data) {
          console.log('Request succeeded with JSON response', data);
          this.setState({
            refund_id: response.razorpay_payment_id
          });
        })
        .catch(function (error) {
          console.log('Request failed', error);
        });
      },
      "prefill": {
        "name": "Gayathri Devi",
        "email": "gayathri@razorpay.com"
      },
      "notes": {
        "address": "Hello World"
      },
      "theme": {
        "color": "#1a449c"
      }
    };
    
    var rzp = new window.Razorpay(options);
    rzp.open();

  }
  

  render () { 


    return (
      <div className="subscribe-module">      
      <div className="columns">
        <Subscribe planName="Bronze" price="30000" users="25" click={this.openCheckout} />
        <Subscribe planName="Silver" price="47000" users="40"  click={this.openCheckout}/>
        <Subscribe planName="Gold" price="55000" users="50"  click={this.openCheckout}/>
        <Subscribe planName="Platinum" price="62000" users="70"  click={this.openCheckout}/>
      </div>
       
      </div>
    )
  }
}
