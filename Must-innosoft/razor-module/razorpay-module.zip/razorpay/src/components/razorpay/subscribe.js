import React, { Component } from 'react'
import 'bulma/css/bulma.css'
import "bulma-o-steps/bulma-steps.min.css";
import "bulma-pricingtable/dist/css/bulma-pricingtable.min.css";


export default class subscribe extends Component {
  render() {
    const{planName,price,users,click} =this.props;
    return (
   
      <div className="column is-3">
      <div className="pricing-table">
          <div className="pricing-plan is-warning">
            <div className="plan-header" >
             {planName}
            </div>
            <div className="plan-price"><span className="plan-price-amount"><span className="plan-price-currency">&#x20B9;</span>{price}</span>/month</div>
            <div className="plan-items">
              <div className="plan-item">20GB Storage</div>
              <div className="plan-item">{users} Users</div>           
              <div className="plan-item">-</div>
            </div>
            <div className="plan-footer">
              <button className="button is-fullwidth" onClick={()=>click(price)}>Choose</button>
            </div>
          </div>
        </div>
      </div>
        

    
    )
  }
}
