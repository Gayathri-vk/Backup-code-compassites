import React from 'react';
import logo from './logo.svg';
import './App.css';
import RazorPay from './components/razorpay/razorpay';
function App() {
  return (
    <div className="App">
      <header className="App-header">
       <RazorPay/>
      </header>
    </div>
  );
}

export default App;
