import React, { Component } from 'react'

export default class Cart extends Component {
  render() {
    return (
      <div>
        <h3>Cart</h3>
      </div>
    )
  }
}
