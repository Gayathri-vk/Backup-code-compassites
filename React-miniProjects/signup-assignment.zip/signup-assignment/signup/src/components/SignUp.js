import React, { Component } from 'react'
import '../style.css';
export default class SignUp extends Component {
    constructor (props) {
        super(props)
     
        this.state = {
          userName: '',
          password:'',
        }
    }
    handleUserName =(e)=>{
      const userName = e.target.value
      
      if (/[^0-9a-zA-Z\s\@]+$/.test(userName) ){       
        console.log(JSON.stringify(userName), "=> invalid");        
    }    
   else {
        console.log(JSON.stringify(userName), "=> valid");
    }
      this.setState({
          userName:e.target.value,          
      })
    }
    handlePassword =(e)=>{
        const password = e.target.value
        if (/^[0-9a-zA-Z](?=.*[A-Z])(?=.*[@#$%^&+=]){6,}.*$/.test(password) ){       
            console.log(JSON.stringify(password), "=> pwd valid");        
        }    
       else {
            console.log(JSON.stringify(password), "=> pwd invalid");
        }
          this.setState({
            password:e.target.value,          
          })
    }
    render() {
        return (
            <div className="sign-up-block">
                <h1>Sign Up</h1>
                <form>
                    <div className="form-group">
                        <label htmlFor="UserName">UserName</label>
                        <input type="text" 
                               className="form-control" 
                               id="UserName" 
                               placeholder="Enter UserName" 
                               value={this.state.userName}
                               onChange={this.handleUserName} required/>                            
                   </div>
                   <div className="form-group">
                        <label htmlFor="Password">Password</label>
                        <input type="password" 
                        className="form-control" 
                        id="Password" 
                        placeholder="Password"
                        value={this.state.password}
                        onChange={this.handlePassword} required/>
                   </div>
                   <div className="form-group">
                        <label htmlFor="Password-repeat">Re-enter Password</label>
                        <input type="password" className="form-control" id="Password-repeat" placeholder="re-enter Password" required/>
                   </div> 
                      
                   <div className="btn-block">
                     <button type="submit" className="btn btn-primary">SignUp</button>
                   </div>                
                    
                </form>

            </div>
                        )
                    }
                }
