import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import SignUp from './components/SignUp'
import './App.css';

function App() {
  return (
  <div>
    <SignUp/>
  </div>
     
   
  );
}

export default App;
